package me.coder.astparser;

public class HelloWorld {
    public String sayHello(String name) {
        return "Hello, " + name + "!";
    }

    public int addNumbers(int a, int b) {
        return a + b;
    }
}
